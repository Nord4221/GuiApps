#include "MyThread.h"

MyThread::MyThread()
{

}

void MyThread::run()
{
    exec();
}
