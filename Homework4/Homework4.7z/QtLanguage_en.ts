<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US">
<context>
    <name>TextEditor</name>
    <message>
        <location filename="TextEditor.ui" line="14"/>
        <source>TextEditor</source>
        <translation>TextEditor</translation>
    </message>
    <message>
        <location filename="TextEditor.ui" line="27"/>
        <source>Help</source>
        <translation>Help</translation>
    </message>
    <message>
        <location filename="TextEditor.ui" line="40"/>
        <source>Open File</source>
        <translation>Open File</translation>
    </message>
    <message>
        <location filename="TextEditor.ui" line="53"/>
        <source>Save File</source>
        <translation>Save File</translation>
    </message>
    <message>
        <location filename="TextEditor.ui" line="60"/>
        <source>ReadOnly mode</source>
        <translation>ReadOnly mode</translation>
    </message>
    <message>
        <location filename="TextEditor.ui" line="73"/>
        <source>En/Ru</source>
        <translation>En/Ru</translation>
    </message>
    <message>
        <location filename="TextEditor.ui" line="87"/>
        <source>Change file open key</source>
        <translation>Change file open key</translation>
    </message>
    <message>
        <location filename="TextEditor.cpp" line="38"/>
        <source>Choose file to open</source>
        <translation>Choose file to open</translation>
    </message>
    <message>
        <location filename="TextEditor.cpp" line="38"/>
        <source>Files(*.txt)</source>
        <translation>Files(*.txt)</translation>
    </message>
    <message>
        <location filename="TextEditor.cpp" line="53"/>
        <source>Can&apos;t read anything from file - </source>
        <translation>Can&apos;t read anything from file - </translation>
    </message>
    <message>
        <location filename="TextEditor.cpp" line="143"/>
        <source>File opened - </source>
        <translation>File opened - </translation>
    </message>
    <message>
        <location filename="TextEditor.cpp" line="148"/>
        <source>Can&apos;t open file - </source>
        <translation>Can&apos;t open file - </translation>
    </message>
    <message>
        <location filename="TextEditor.cpp" line="154"/>
        <source>Can&apos;t find file : </source>
        <translation>Can&apos;t find file : </translation>
    </message>
</context>
</TS>
