<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru_RU">
<context>
    <name>TextEditor</name>
    <message>
        <location filename="TextEditor.ui" line="14"/>
        <source>TextEditor</source>
        <translation>Текстовый редактор</translation>
    </message>
    <message>
        <location filename="TextEditor.ui" line="27"/>
        <source>Help</source>
        <translation>Помощь</translation>
    </message>
    <message>
        <location filename="TextEditor.ui" line="40"/>
        <source>Open File</source>
        <translation>Открыть файл</translation>
    </message>
    <message>
        <location filename="TextEditor.ui" line="53"/>
        <source>Save File</source>
        <translation>Сохранить файл</translation>
    </message>
    <message>
        <location filename="TextEditor.ui" line="60"/>
        <source>ReadOnly mode</source>
        <translation>Режим толькодля чтения</translation>
    </message>
    <message>
        <location filename="TextEditor.ui" line="73"/>
        <source>En/Ru</source>
        <translation>Анг\Ру</translation>
    </message>
    <message>
        <location filename="TextEditor.ui" line="87"/>
        <source>Change file open key</source>
        <translation>Изменить кнопку открытия файла</translation>
    </message>
    <message>
        <location filename="TextEditor.cpp" line="38"/>
        <source>Choose file to open</source>
        <translation>Выберите файл</translation>
    </message>
    <message>
        <location filename="TextEditor.cpp" line="38"/>
        <source>Files(*.txt)</source>
        <translation>Файлы(*.txt)</translation>
    </message>
    <message>
        <location filename="TextEditor.cpp" line="53"/>
        <source>Can&apos;t read anything from file - </source>
        <translation>Нельзя ничего прочесть из файла - </translation>
    </message>
    <message>
        <location filename="TextEditor.cpp" line="143"/>
        <source>File opened - </source>
        <translation>Файл отерыт - </translation>
    </message>
    <message>
        <location filename="TextEditor.cpp" line="148"/>
        <source>Can&apos;t open file - </source>
        <translation>Не получается открыть файл </translation>
    </message>
    <message>
        <location filename="TextEditor.cpp" line="154"/>
        <source>Can&apos;t find file : </source>
        <translation>Не получается обнаружить файл : </translation>
    </message>
</context>
</TS>
